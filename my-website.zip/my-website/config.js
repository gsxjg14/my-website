// This file contains sensitive information and should be added to .gitignore
// Store your Telegram bot token and chat ID here
const config = {
  telegramBotToken: "YOUR_TELEGRAM_BOT_TOKEN", // Replace with your actual token
  telegramChatId: "YOUR_TELEGRAM_CHAT_ID", // Replace with your actual chat ID
  adminUsername: "admin", // Default admin username
  adminPassword: "admin123", // Default admin password
}

// If environment variables are supported, try to use them
if (typeof process !== "undefined" && process.env) {
  config.telegramBotToken = process.env.TELEGRAM_BOT_TOKEN || config.telegramBotToken
  config.telegramChatId = process.env.TELEGRAM_CHAT_ID || config.telegramChatId
  config.adminUsername = process.env.ADMIN_USERNAME || config.adminUsername
  config.adminPassword = process.env.ADMIN_PASSWORD || config.adminPassword
}
